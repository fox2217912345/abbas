#!/bin/bash

# Render.com Deployment Script for CryptoSignal AI Pro
# This script creates a deployment package for Render.com

echo "🚀 Deploying CryptoSignal AI Pro to cloud..."

# Check if we're in a git repository
if [ ! -d ".git" ]; then
    echo "📁 Initializing git repository..."
    git init
    git config --global user.email "deployment@cryptosignal-ai.com"
    git config --global user.name "CryptoSignal AI Deployer"
fi

# Add all files
echo "📦 Adding files to repository..."
git add .

# Create deployment commit
echo "💾 Committing changes..."
git commit -m "Deploy CryptoSignal AI Pro with enhanced API integrations"

# Check if render.yaml exists, create if needed
if [ ! -f "render.yaml" ]; then
    echo "🔧 Creating Render.com configuration..."
    cat > render.yaml << EOF
services:
  - type: web
    name: cryptosignal-ai-pro
    env: python
    plan: free
    buildCommand: pip install -r requirements.txt
    startCommand: streamlit run app.py --server.address=0.0.0.0 --server.port=\$PORT
    envVars:
      - key: STREAMLIT_SERVER_ENABLE_CORS
        value: false
      - key: STREAMLIT_SERVER_ENABLE_XSRF_PROTECTION
        value: false
EOF
    echo "✅ Render.com configuration created"
fi

echo "🎉 Deployment package ready!"
echo ""
echo "📋 Next steps:"
echo "1. Create a GitHub repository and push this code"
echo "2. Go to https://render.com and connect your GitHub"
echo "3. Create a new Web Service from this repository"
echo "4. The app will be automatically deployed with a public URL"
echo ""
echo "🔑 Don't forget to add your API keys:"
echo "- OpenAI API Key: In Render dashboard > Environment Variables"
echo "- Binance API Keys: Optional, also in Environment Variables"
echo "- TradingView Widget ID: Optional"