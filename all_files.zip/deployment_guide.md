# CryptoSignal AI Pro - Deployment Guide

## 🚀 Quick Start

### Local Development Setup

1. **Install Python Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Set Environment Variables:**
   ```bash
   export OPENAI_API_KEY="your_openai_api_key_here"
   ```

3. **Run the Application:**
   ```bash
   streamlit run app.py
   ```

4. **Access the App:**
   - Open your browser to `http://localhost:8501`

### Cloud Deployment to Render.com (Recommended)

#### Step 1: Prepare Your Repository
```bash
git init
git add .
git commit -m "Initial commit: CryptoSignal AI Pro"
git push origin main
```

#### Step 2: Deploy to Render.com

1. **Create Account:** Sign up at [render.com](https://render.com)

2. **Create Web Service:**
   - Click "New +" → "Web Service"
   - Connect your GitHub repository
   - Choose "Build and deploy from a Git repository"

3. **Configure Build Settings:**
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `streamlit run app.py --server.port=$PORT --server.address=0.0.0.0`
   - **Environment:** Python 3.11

4. **Environment Variables:**
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   STREAMLIT_SERVER_PORT=10000
   STREAMLIT_SERVER_ADDRESS=0.0.0.0
   ```

5. **Add PostgreSQL Database:**
   - In Render dashboard → "New +" → "PostgreSQL"
   - Note the connection string
   - Add to environment variables:
     ```
     DATABASE_URL=postgresql://username:password@host:port/database
     ```

6. **Deploy:**
   - Click "Create Web Service"
   - Wait for deployment to complete (5-10 minutes)

### Alternative Cloud Platforms

#### Heroku Deployment
```bash
# Install Heroku CLI
heroku create your-cryptosignal-app
heroku addons:create heroku-postgresql:hobby-dev
heroku config:set OPENAI_API_KEY=your_key_here
git push heroku main
```

#### AWS EC2 Deployment
```bash
# Launch EC2 instance (Ubuntu)
sudo apt update
sudo apt install python3-pip python3-venv -y
git clone your-repo
cd cryptosignal-ai-pro
pip3 install -r requirements.txt
export OPENAI_API_KEY=your_key_here
nohup streamlit run app.py --server.port=8501 --server.address=0.0.0.0 &
```

#### Google Cloud Run
```bash
# Create Dockerfile
echo 'FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8080
CMD ["streamlit", "run", "app.py", "--server.port=8080", "--server.address=0.0.0.0"]' > Dockerfile

# Build and deploy
gcloud run deploy cryptosignal-ai-pro --source . --platform managed --allow-unauthenticated
```

## 🔧 Configuration Options

### Database Configuration

**Local Development (SQLite):**
- Database file: `signals.db`
- Auto-created in application directory
- No additional configuration needed

**Production (PostgreSQL):**
- Set `DATABASE_URL` environment variable
- Example: `postgresql://user:pass@localhost:5432/dbname`
- Automatic migration handled by SQLAlchemy

### API Keys and Security

1. **OpenAI API Key:**
   - Required for AI analysis
   - Stored securely in session state
   - Never logged or stored permanently

2. **Binance API (Optional):**
   - Not required for public data
   - Add for enhanced rate limits:
     ```
     BINANCE_API_KEY=your_binance_api_key
     BINANCE_SECRET=your_binance_secret
     ```

3. **News API (Optional):**
   - For real news sentiment:
     ```
     NEWSAPI_KEY=your_newsapi_key
     ```

### Environment Variables Reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `OPENAI_API_KEY` | Yes | None | OpenAI API key for AI analysis |
| `DATABASE_URL` | No | SQLite | Database connection string |
| `BINANCE_API_KEY` | No | None | Binance API key (optional) |
| `BINANCE_SECRET` | No | None | Binance API secret (optional) |
| `NEWSAPI_KEY` | No | None | NewsAPI key for real news (optional) |
| `PORT` | No | 8501 | Streamlit server port |
| `HOST` | No | localhost | Streamlit server host |

## 📊 Monitoring and Maintenance

### Health Checks
```bash
# Check application health
curl https://your-app.render.com/health

# Monitor logs
heroku logs --tail
```

### Database Maintenance
```python
# Backup database
pg_dump $DATABASE_URL > backup.sql

# Restore database
psql $DATABASE_URL < backup.sql
```

### Performance Optimization

1. **Caching:**
   - Streamlit caching already implemented for API calls
   - Consider Redis for production caching

2. **Rate Limiting:**
   - Binance API limits: 1200 requests/minute
   - OpenAI API limits: 60 requests/minute (GPT-4)
   - Implement exponential backoff for failures

3. **Database Optimization:**
   ```sql
   -- Add indexes for better query performance
   CREATE INDEX idx_signals_coin_timeframe ON signals(coin, timeframe);
   CREATE INDEX idx_signals_timestamp ON signals(timestamp);
   ```

## 🔒 Security Best Practices

### API Key Security
- Never commit API keys to version control
- Use environment variables for all secrets
- Implement key rotation policies
- Monitor API usage for anomalies

### Application Security
- Enable HTTPS in production
- Implement request rate limiting
- Add input validation for all user inputs
- Use secure session management

### Database Security
- Use strong passwords
- Enable SSL connections
- Regular security updates
- Backup encryption

## 🐛 Troubleshooting

### Common Issues

1. **"Database initialization failed"**
   ```bash
   # Check DATABASE_URL format
   echo $DATABASE_URL
   
   # Verify database connectivity
   psql $DATABASE_URL -c "SELECT 1;"
   ```

2. **"OpenAI API key not provided"**
   ```bash
   # Verify environment variable
   echo $OPENAI_API_KEY
   
   # Test API key
   python -c "import openai; client = openai.OpenAI(); client.models.list()"
   ```

3. **"Failed to fetch data from Binance"**
   - Check internet connectivity
   - Verify symbol format (e.g., 'BTC/USDT')
   - Consider rate limiting

4. **TA-Lib installation issues (Linux/Mac):**
   ```bash
   # Ubuntu/Debian
   sudo apt-get install libta-lib-dev
   
   # macOS
   brew install ta-lib
   
   # Then reinstall
   pip install --force-reinstall TA-Lib
   ```

### Log Analysis
```bash
# Streamlit logs
tail -f ~/.streamlit/logs/streamlit.log

# Application logs
tail -f /var/log/application.log

# Database logs
tail -f /var/log/postgresql/postgresql.log
```

## 📈 Scaling Considerations

### Horizontal Scaling
- Load balancer configuration
- Multiple app instances
- Database read replicas

### Vertical Scaling
- Increase instance resources
- Optimize database queries
- Implement connection pooling

### Caching Strategy
- Redis for session data
- CDN for static assets
- API response caching

## 🔄 Continuous Integration/Deployment

### GitHub Actions Example
```yaml
name: Deploy to Render

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Deploy to Render
      run: |
        curl -X POST "https://api.render.com/v1/services" \
          -H "Content-Type: application/json" \
          -d '{"serviceName":"cryptosignal-ai-pro","repository":"your-repo"}'
```

## 📝 Legal and Compliance

### Disclaimers
- Financial advice disclaimer prominently displayed
- Risk warnings for cryptocurrency trading
- Terms of service implementation
- Privacy policy for data handling

### Data Protection
- GDPR compliance if serving EU users
- Data retention policies
- User consent mechanisms
- Right to data deletion

---

## 🎯 Quick Reference

**Most Common Commands:**
```bash
# Local development
streamlit run app.py

# Install dependencies
pip install -r requirements.txt

# Run with specific port
streamlit run app.py --server.port 8080

# Database backup
pg_dump $DATABASE_URL > backup.sql

# View logs
heroku logs --tail
```

**Useful URLs:**
- Application: `https://your-app.render.com`
- Database: `https://your-db.render.com`
- Monitoring: `https://your-app.render.com/health`

For additional support, please refer to the documentation or create an issue in the repository.